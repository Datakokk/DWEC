const camisetasCSV = `color;precio;desc;id;nombre
;;;;
yellowT;44.00€;Sint occaecat deserunt ex incididunt qui sint. Id minim magna labore pariatur nulla quis.;9bdd2;Compton T-Shirt
greyT;33.00€;Ea labore sunt magna labore Lorem aliquip irure eu qui commodo minim sunt magna nisi. Deserunt fugiat ullamco excepteur pariatur fugiat occaecat ut quis ad.;f6be8;Comverges T-Shirt
blackT;16.00€;Quis dolor elit id qui nulla ea esse nulla velit. Occaecat Lorem laboris tempor proident ex.;b55da;Flexigen T-Shirt
pinkT;92.00€;Magna non commodo ipsum nulla aliquip duis enim nostrud pariatur eiusmod. Incididunt ut adipisicing cillum eu Lorem nulla et est.;bc823;Fuelworks T-Shirt
brownT;55.00€;Minim Lorem in officia irure exercitation ea amet. Ipsum aliquip pariatur magna commodo nisi sint esse.;035f0;Futuris T-Shirt
azureT;57.00€;Ad et aliquip esse ut sint velit. Voluptate id ad esse aliquip culpa consectetur esse reprehenderit veniam minim elit eu.;8835a;Isoternia T-Shirt
greenT;55.00€;Et nisi et quis cillum eiusmod eu cupidatat duis. Nostrud veniam minim ullamco et cillum aliquip.;57b9d;Kiosk T-Shirt
orangeT;90.00€;Minim elit minim est ullamco Lorem. Exercitation ex sint nisi dolore cillum nisi cillum anim ullamco.;dc646;Lunchpod T-Shirt
brickT;31.00€;Magna non commodo ipsum nulla aliquip duis enim nostrud pariatur eiusmod. Incididunt ut adipisicing cillum eu Lorem nulla et est.;7w9e0;Masons T-Shirt
violetT;82.00€;Tempor sit irure commodo exercitation do cupidatat eiusmod laborum pariatur enim labore. Laboris amet adipisicing duis mollit.;239b5;Pigzart T-Shirt
arrowT;62.00€;Adipisicing culpa sint cillum eiusmod. Dolor reprehenderit magna velit non culpa ea dolor laborum est nulla deserunt minim.;6d9b0;Poyo T-Shirt
whiteT;99.00€;Adipisicing culpa sint cillum eiusmod. Dolor reprehenderit magna velit non culpa ea dolor laborum est nulla deserunt minim.;6c3b0;Zappix T-Shirt`;